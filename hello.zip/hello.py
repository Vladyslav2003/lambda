print("Hello, World")
